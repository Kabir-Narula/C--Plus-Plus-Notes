#include <iostream>
#include "cylinder.h"
#include "bird.h"

int main(){

    int age{};

    /*

	Cylinder cylinder1(3.3,10.0);
    std::cout << "Volume of cylinder : " << cylinder1.volume() << std::endl;
    std::cout << "Cylinder default color : " << Cylinder::default_color << std::endl;
    std::cout << "Cylinder default color : " << cylinder1.default_color << std::endl;
	
	std::cout << std::endl;
	std::cout << "Other constants" << std::endl;
	std::cout << "Int constant : " << Cylinder::INT_CONSTANT << std::endl;
	std::cout << "Color(enum) constant : " << Cylinder::COLOR_CONSTANT << std::endl;
	std::cout << "Char ptr constant : " << Cylinder::CHAR_PTR_CONSTANT << std::endl;
	std::cout << "arr[2] : " << Cylinder::INT_ARRAY_CONSTANT[2] << std::endl;
	std::cout << "float constant : " << Cylinder::FLOAT_CONSTANT << std::endl;
	std::cout << "str_arr[1] : " << Cylinder::STRING_ARRAY_CONSTANT[1] << std::endl;
	
	
	std::cout << std::endl;
	std::cout << "Can't modify those static constants" << std::endl;
	//Cylinder::INT_CONSTANT = 6; // Compiler error.
	
	std::cout << std::endl;
	std::cout << "raw constants" << std::endl;
	std::cout << "WEIRD_FLOAT : " << cylinder1.WEIRD_FLOAT << std::endl;
	std::cout << "WEIRD_C_STRING : " << cylinder1.WEIRD_C_STRING << std::endl;
	std::cout << "WEIRD_INT_ARRAY[3] : " << cylinder1.WEIRD_INT_ARRAY_CONSTANT[3] << std::endl;


    std::cout << std::endl;
	std::cout << "Constant initialized with other constant" << std::endl;
	std::cout << "BIRD_WEIGHT_CONSTANT : " << Bird::BIRD_WEIGHT_CONSTANT << std::endl;
    */
	
	
   
    return 0;
}