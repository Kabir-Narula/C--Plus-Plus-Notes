
int incr_mult(int a, int b);