int max( int a, int b);//Declaration
int min(int a, int b);