#include <iostream>
#include "square.h"

int main(){

    Square s1(100.0);


    return 0;
}