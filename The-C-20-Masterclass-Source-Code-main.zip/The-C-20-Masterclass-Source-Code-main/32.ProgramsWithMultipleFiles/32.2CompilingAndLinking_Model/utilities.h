//Declarations
double add( double a, double b);
double multiply(double a, double b);